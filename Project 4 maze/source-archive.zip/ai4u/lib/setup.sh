#!/bin/bash

wget -O easymock-3.0.zip http://sourceforge.net/projects/easymock/files/EasyMock/3.0/easymock-3.0.zip/download
unzip easymock-3.0.zip
rm easymock-3.0.zip
