package com.ai4u.games.mankala;

import com.ai4u.core.display.GameDisplayer;

/**
 * This is a displayer for the Mankala states.
 * 
 * @author igalk
 */
public class MankalaDisplayer implements GameDisplayer<MankalaMove, MankalaBoard, MankalaPlayer> {

	@Override
	public void display(MankalaBoard board) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void gameOver(MankalaBoard board) {
		// TODO Auto-generated method stub
		
	}

}
