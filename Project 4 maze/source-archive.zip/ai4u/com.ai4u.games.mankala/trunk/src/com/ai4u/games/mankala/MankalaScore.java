package com.ai4u.games.mankala;

import com.ai4u.core.logic.computer.evaluation.GameStateScore;

/**
 * Represents the score of a state.
 * 
 * @author igalk
 */
public class MankalaScore implements GameStateScore<MankalaMove> {

	@Override
	public int compareTo(GameStateScore<MankalaMove> o) {
		// TODO Auto-generated method stub
		return 0;
	}

}
