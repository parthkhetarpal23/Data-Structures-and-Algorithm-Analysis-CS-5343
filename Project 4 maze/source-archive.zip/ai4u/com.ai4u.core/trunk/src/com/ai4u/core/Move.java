package com.ai4u.core;

/**
 * This interface describes a move in the game.
 * 
 * @author kreich
 */
public interface Move {

	// nothing here yet.
	
}
