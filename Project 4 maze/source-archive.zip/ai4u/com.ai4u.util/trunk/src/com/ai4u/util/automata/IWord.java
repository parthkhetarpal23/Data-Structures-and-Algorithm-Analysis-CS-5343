package com.ai4u.util.automata;

public interface IWord {

}
