package com.ai4u.util.automata;


public interface IAutomata {

	public boolean accepts(IWord w);
	
}
