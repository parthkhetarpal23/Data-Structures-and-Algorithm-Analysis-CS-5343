
public class Test {
public static void main(String args[])
{
	Kruskal kruskal = new Kruskal();
    System.out.println("---- The Minimum Spanning Tree of the Cities of Dallas ----");
    System.out.println();
    kruskal.kruskal();  
}
}
